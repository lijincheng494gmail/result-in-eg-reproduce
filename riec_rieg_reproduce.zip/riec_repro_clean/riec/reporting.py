from pathlib import Path
from typing import Dict
import json

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def save_metrics_table(df: pd.DataFrame, out_csv: Path) -> None:
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_csv, index=False)


def save_selection_json(picks: Dict[str, str], out_json: Path) -> None:
    out_json.parent.mkdir(parents=True, exist_ok=True)
    with out_json.open("w", encoding="utf-8") as f:
        json.dump(picks, f, indent=2, ensure_ascii=False)


def plot_bar_summary(df: pd.DataFrame, metric: str, out_path: Path, title: str, ylabel: str | None = None) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(10, 4))
    plt.bar(df["model_name"], df[metric])
    plt.xticks(rotation=30, ha="right")
    plt.title(title)
    if ylabel is not None:
        plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()


def plot_fit_overlay(
    x: np.ndarray,
    y_obs: np.ndarray,
    preds: Dict[str, np.ndarray],
    out_path: Path,
    title: str,
    xlabel: str,
    ylabel: str,
    max_points: int = 2000,
) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    x = np.asarray(x, dtype=float)
    y_obs = np.asarray(y_obs, dtype=float)
    if len(x) > max_points:
        idx = np.linspace(0, len(x) - 1, max_points).astype(int)
        x_plot = x[idx]
        y_plot = y_obs[idx]
    else:
        idx = None
        x_plot = x
        y_plot = y_obs

    plt.figure(figsize=(10, 4))
    plt.plot(x_plot, y_plot, label="observed", linewidth=1.5)
    for name, yhat in preds.items():
        yhat = np.asarray(yhat, dtype=float)
        if len(yhat) != len(x):
            continue
        yhat_plot = yhat[idx] if idx is not None else yhat
        plt.plot(x_plot, yhat_plot, label=name, linewidth=1.0)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=300)
    plt.close()
