from dataclasses import dataclass
from typing import Any, Callable, Dict, Sequence, Tuple

import numpy as np
import pandas as pd


def bic_from_sse(sse: float, n: int, k: int, n_eff: int | None = None) -> float:
    if n_eff is None:
        n_eff = n
    n_eff = int(n_eff)
    if n_eff <= 0:
        raise ValueError("n_eff must be positive")
    sse = float(sse)
    sse = max(sse, 1e-30)
    return float(n_eff * np.log(sse / n_eff) + k * np.log(n_eff))


def mse(y: np.ndarray, yhat: np.ndarray) -> float:
    return float(np.mean((y - yhat) ** 2))


def evaluate_model_on_indices(model, x: np.ndarray, y: np.ndarray, train_idx: np.ndarray, test_idx: np.ndarray) -> Tuple[float, float]:
    x_tr, y_tr = x[train_idx], y[train_idx]
    x_te, y_te = x[test_idx], y[test_idx]
    m = model.fit(x_tr, y_tr)
    yhat_te = m.predict(x_te)
    yhat_tr = m.predict(x_tr)
    test_mse = mse(y_te, yhat_te)
    train_sse = float(np.sum((y_tr - yhat_tr) ** 2))
    return test_mse, train_sse


@dataclass(frozen=True)
class ModelSpec:
    name: str
    param_count: int
    factory: Callable[[], Any]


def run_riec_selection(
    x: np.ndarray,
    y: np.ndarray,
    models: Sequence[ModelSpec],
    splits: Sequence[Tuple[np.ndarray, np.ndarray]],
    baseline_name: str,
    lambda_weight: float,
    n_eff: int | None = None,
) -> Tuple[pd.DataFrame, Dict[str, str]]:
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    n = len(y)

    cv_risks: Dict[str, float] = {}
    bics: Dict[str, float] = {}
    ks: Dict[str, int] = {}

    for spec in models:
        name = spec.name
        k = int(spec.param_count)
        ks[name] = k

        fold_mse = []
        for train_idx, test_idx in splits:
            m = spec.factory()
            mse_te, _ = evaluate_model_on_indices(m, x, y, train_idx, test_idx)
            fold_mse.append(mse_te)
        cv_risks[name] = float(np.mean(fold_mse))

        m_full = spec.factory()
        m_full.fit(x, y)
        yhat = m_full.predict(x)
        sse = float(np.sum((y - yhat) ** 2))
        bics[name] = bic_from_sse(sse, n=n, k=k, n_eff=n_eff)

    if baseline_name not in cv_risks:
        raise ValueError(f"baseline_name='{baseline_name}' not in models")

    base_cv = max(float(cv_risks[baseline_name]), 1e-30)

    rows = []
    for name in cv_risks:
        cv = max(float(cv_risks[name]), 1e-30)
        xpe = base_cv / cv
        c_lam = float(bics[name] + lambda_weight * np.log(1.0 / xpe))
        rows.append(
            {
                "model_name": name,
                "k_params": ks[name],
                "bic": float(bics[name]),
                "cv_risk": float(cv),
                "xpe": float(xpe),
                "c_lambda": float(c_lam),
            }
        )

    df = pd.DataFrame(rows)
    bic_best = str(df.sort_values("bic", ascending=True).iloc[0]["model_name"])
    cv_best = str(df.sort_values("cv_risk", ascending=True).iloc[0]["model_name"])
    riec_best = str(df.sort_values("c_lambda", ascending=True).iloc[0]["model_name"])

    df = df.sort_values("c_lambda", ascending=True).reset_index(drop=True)
    picks = {"bic_best": bic_best, "cv_best": cv_best, "riec_best": riec_best}
    return df, picks
