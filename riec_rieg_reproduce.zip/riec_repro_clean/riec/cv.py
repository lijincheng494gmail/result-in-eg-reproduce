from typing import List, Tuple

import numpy as np
import pandas as pd


def make_group_splits(df: pd.DataFrame, group_col: str) -> List[Tuple[np.ndarray, np.ndarray]]:
    if group_col not in df.columns:
        raise ValueError(f"group_col '{group_col}' not in DataFrame")
    groups = df[group_col].astype(str).to_numpy()
    idx = np.arange(len(df))
    uniq = pd.unique(groups)
    splits: List[Tuple[np.ndarray, np.ndarray]] = []
    for g in uniq:
        test_mask = groups == g
        test_idx = idx[test_mask]
        train_idx = idx[~test_mask]
        if len(test_idx) == 0 or len(train_idx) == 0:
            continue
        splits.append((train_idx, test_idx))
    if not splits:
        raise ValueError("no valid splits")
    return splits
