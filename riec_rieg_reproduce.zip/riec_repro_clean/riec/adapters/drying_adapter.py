from pathlib import Path

import pandas as pd


def load_drying_long(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "t" not in df.columns or "MR" not in df.columns:
        raise ValueError("drying CSV must include columns: t, MR")
    if "condition_id" not in df.columns:
        if "T" in df.columns:
            df = df.copy()
            df["condition_id"] = df["T"].astype(str)
        else:
            raise ValueError("drying CSV missing condition_id (or T to build it)")
    cols = [c for c in ["t", "MR", "condition_id", "T"] if c in df.columns]
    out = df[cols].copy()
    out["condition_id"] = out["condition_id"].astype(str)
    return out
