from pathlib import Path
from typing import List

import pandas as pd


def load_optics_long(paths: List[Path]) -> pd.DataFrame:
    dfs = []
    for p in paths:
        df = pd.read_csv(p)
        if "wavenumber" not in df.columns or "reflectance" not in df.columns:
            raise ValueError(f"optics CSV missing required columns: {p}")
        if "condition_id" not in df.columns:
            df = df.copy()
            df["condition_id"] = p.stem
        dfs.append(df[["wavenumber", "reflectance", "condition_id"]])
    out = pd.concat(dfs, ignore_index=True)
    out["condition_id"] = out["condition_id"].astype(str)
    return out
