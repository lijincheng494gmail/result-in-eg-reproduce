from pathlib import Path

import numpy as np
import pandas as pd


def _trapz(y: np.ndarray, x: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    if hasattr(np, "trapz"):
        return float(np.trapz(y, x))
    return float(np.trapezoid(y, x))


def compute_rtd_E(t: np.ndarray, c: np.ndarray, baseline_points: int = 50) -> np.ndarray:
    t = np.asarray(t, dtype=float)
    c = np.asarray(c, dtype=float)
    if len(t) != len(c):
        raise ValueError("t and c must have same length")
    if len(t) < baseline_points + 5:
        baseline_points = max(5, len(t)//10)
    baseline = float(np.median(c[:baseline_points]))
    c_adj = c - baseline
    c_adj = np.where(c_adj < 0, 0.0, c_adj)
    area = _trapz(c_adj, t)
    if not np.isfinite(area) or area <= 0:
        raise ValueError("cannot normalize tracer response")
    return c_adj / area


def load_rtd_runs_long(path_data3: Path) -> pd.DataFrame:
    df = pd.read_csv(path_data3)
    if "时间" not in df.columns:
        raise ValueError("data3.csv must include column: 时间")
    t = df["时间"].to_numpy(dtype=float)
    run_cols = [c for c in df.columns if c != "时间"]
    if len(run_cols) < 1:
        raise ValueError("no run columns found")
    rows = []
    for j, col in enumerate(run_cols, start=1):
        c = df[col].to_numpy(dtype=float)
        E = compute_rtd_E(t, c)
        rows.append(pd.DataFrame({"t": t, "E": E, "run_id": f"run{j}"}))
    out = pd.concat(rows, ignore_index=True)
    out["run_id"] = out["run_id"].astype(str)
    return out
