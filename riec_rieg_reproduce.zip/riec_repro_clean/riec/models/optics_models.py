from dataclasses import dataclass

import numpy as np
from scipy import optimize


def _as_1d(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    if x.ndim != 1:
        raise ValueError("x must be 1D")
    return x


def _poly_design(xn: np.ndarray, deg: int) -> np.ndarray:
    return np.vander(xn, N=deg + 1, increasing=True)


def _guess_omega(w: np.ndarray, y: np.ndarray) -> float:
    w = np.asarray(w, dtype=float)
    y = np.asarray(y, dtype=float)
    n = w.size
    if n < 32:
        return 0.01
    dw = float(np.median(np.diff(w)))
    if not np.isfinite(dw) or dw <= 0:
        return 0.01
    p = np.polyfit(w, y, deg=1)
    y_det = y - np.polyval(p, w)
    y_det = y_det - np.mean(y_det)
    ft = np.fft.rfft(y_det)
    freqs = np.fft.rfftfreq(n, d=dw)
    if freqs.size < 3:
        return 0.01
    idx = int(np.argmax(np.abs(ft[1:])) + 1)
    f0 = float(freqs[idx])
    omega0 = 2.0 * np.pi * f0
    return float(np.clip(omega0, 1e-6, 0.5))


@dataclass
class CosinePolyModel:
    deg: int = 0
    name: str = "cos_poly"
    param_count: int = 0
    coef: np.ndarray | None = None
    A: float | None = None
    omega: float | None = None
    phi: float | None = None
    x0: float | None = None
    xs: float | None = None

    def __post_init__(self) -> None:
        self.deg = int(self.deg)
        if self.deg < 0:
            raise ValueError("deg must be >= 0")
        self.name = f"cos_poly_deg{self.deg}"
        self.param_count = int(self.deg + 4)

    def _forward(self, w: np.ndarray, coef: np.ndarray, A: float, omega: float, phi: float) -> np.ndarray:
        w = _as_1d(w)
        xn = (w - self.x0) / self.xs
        Phi = _poly_design(xn, self.deg)
        base = Phi @ coef
        return base + A * np.cos(omega * w + phi)

    def fit(self, w: np.ndarray, y: np.ndarray) -> "CosinePolyModel":
        w = _as_1d(w)
        y = np.asarray(y, dtype=float)
        if y.shape != w.shape:
            raise ValueError("w and y must have same shape")
        self.x0 = float(np.mean(w))
        span = float(np.max(w) - np.min(w))
        self.xs = float(span if span > 0 else 1.0)
        coef0 = np.zeros(self.deg + 1, dtype=float)
        coef0[0] = float(np.mean(y))
        A0 = float(0.5 * (np.max(y) - np.min(y) + 1e-12))
        omega0 = _guess_omega(w, y)
        phi0 = 0.0
        p0 = np.concatenate([coef0, [A0, omega0, phi0]])
        lower = np.full_like(p0, -np.inf)
        upper = np.full_like(p0, np.inf)
        lower[-2] = 1e-6
        upper[-2] = 0.5
        lower[-1] = -np.pi
        upper[-1] = np.pi

        def residual(p: np.ndarray) -> np.ndarray:
            coef = p[: self.deg + 1]
            A, omega, phi = p[-3], p[-2], p[-1]
            return self._forward(w, coef, A, omega, phi) - y

        res = optimize.least_squares(residual, x0=p0, bounds=(lower, upper), max_nfev=20000)
        p_hat = res.x
        self.coef = p_hat[: self.deg + 1]
        self.A = float(p_hat[-3])
        self.omega = float(p_hat[-2])
        self.phi = float(p_hat[-1])
        return self

    def predict(self, w: np.ndarray) -> np.ndarray:
        if self.coef is None or self.A is None or self.omega is None or self.phi is None:
            raise RuntimeError("model not fitted")
        return self._forward(_as_1d(w), self.coef, self.A, self.omega, self.phi)
