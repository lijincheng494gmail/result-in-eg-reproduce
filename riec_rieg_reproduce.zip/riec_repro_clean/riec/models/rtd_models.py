from dataclasses import dataclass

import numpy as np
from scipy import optimize, stats


def _safe_trapz(y: np.ndarray, x: np.ndarray) -> float:
    y = np.asarray(y, dtype=float)
    x = np.asarray(x, dtype=float)
    if y.size != x.size:
        raise ValueError("x and y must have same length")
    if y.size < 2:
        return 0.0
    if hasattr(np, "trapz"):
        return float(np.trapz(y, x))
    return float(np.trapezoid(y, x))


def _unique_grid(t: np.ndarray):
    t = np.asarray(t, dtype=float)
    return np.unique(t, return_inverse=True)


def _collapse_duplicates(t: np.ndarray, e: np.ndarray):
    t_u, inv = _unique_grid(t)
    e = np.asarray(e, dtype=float)
    sums = np.bincount(inv, weights=e)
    counts = np.bincount(inv)
    counts = np.maximum(counts, 1)
    e_mean = sums / counts
    e_mean = np.clip(e_mean, 0.0, None)
    area = _safe_trapz(e_mean, t_u)
    if np.isfinite(area) and area > 0:
        e_mean = e_mean / area
    return t_u, e_mean


def _normalize_density(t: np.ndarray, e: np.ndarray) -> np.ndarray:
    area = _safe_trapz(e, t)
    if not np.isfinite(area) or area <= 0:
        raise ValueError("density normalization failed")
    return e / area


def _mse(y: np.ndarray, yhat: np.ndarray) -> float:
    return float(np.mean((y - yhat) ** 2))


@dataclass
class GammaRTD:
    name: str = "gamma_2p"
    param_count: int = 2
    a: float | None = None
    s: float | None = None

    def _pdf(self, t: np.ndarray, a: float, s: float) -> np.ndarray:
        e = stats.gamma.pdf(t, a=a, scale=s)
        return np.nan_to_num(e, nan=0.0, posinf=0.0, neginf=0.0)

    def fit(self, t: np.ndarray, e: np.ndarray):
        t_u, e_u = _collapse_duplicates(t, e)
        mu = float(_safe_trapz(t_u * e_u, t_u))
        var = float(_safe_trapz(((t_u - mu) ** 2) * e_u, t_u))
        var = max(var, 1e-12)
        a0 = max(mu * mu / var, 1e-3)
        s0 = max(var / mu, 1e-6)

        def obj(p: np.ndarray) -> float:
            a, s = p
            if a <= 0 or s <= 0:
                return 1e18
            pred = _normalize_density(t_u, self._pdf(t_u, a, s))
            return _mse(e_u, pred)

        res = optimize.minimize(obj, x0=np.array([a0, s0]), method="Nelder-Mead", options={"maxiter": 5000, "xatol": 1e-10, "fatol": 1e-12})
        a_hat, s_hat = res.x
        self.a = float(max(a_hat, 1e-9))
        self.s = float(max(s_hat, 1e-9))
        return self

    def predict(self, t: np.ndarray) -> np.ndarray:
        if self.a is None or self.s is None:
            raise RuntimeError("model not fitted")
        t_u, inv = _unique_grid(t)
        pred_u = _normalize_density(t_u, self._pdf(t_u, self.a, self.s))
        return pred_u[inv]


@dataclass
class LogNormalRTD:
    name: str = "lognormal_2p"
    param_count: int = 2
    mu: float | None = None
    sigma: float | None = None

    def _pdf(self, t: np.ndarray, mu: float, sigma: float) -> np.ndarray:
        e = stats.lognorm.pdf(t, s=sigma, scale=np.exp(mu))
        return np.nan_to_num(e, nan=0.0, posinf=0.0, neginf=0.0)

    def fit(self, t: np.ndarray, e: np.ndarray):
        t_u, e_u = _collapse_duplicates(t, e)
        mu_t = float(_safe_trapz(t_u * e_u, t_u))
        var_t = float(_safe_trapz(((t_u - mu_t) ** 2) * e_u, t_u))
        var_t = max(var_t, 1e-12)
        sigma0 = float(np.sqrt(np.log(1.0 + var_t / (mu_t ** 2 + 1e-12))))
        mu0 = float(np.log(mu_t + 1e-12) - 0.5 * sigma0 ** 2)

        def obj(p: np.ndarray) -> float:
            mu, sigma = p
            if sigma <= 0:
                return 1e18
            pred = _normalize_density(t_u, self._pdf(t_u, mu, sigma))
            return _mse(e_u, pred)

        res = optimize.minimize(obj, x0=np.array([mu0, sigma0]), method="Nelder-Mead", options={"maxiter": 5000, "xatol": 1e-10, "fatol": 1e-12})
        mu_hat, sigma_hat = res.x
        self.mu = float(mu_hat)
        self.sigma = float(max(sigma_hat, 1e-9))
        return self

    def predict(self, t: np.ndarray) -> np.ndarray:
        if self.mu is None or self.sigma is None:
            raise RuntimeError("model not fitted")
        t_u, inv = _unique_grid(t)
        pred_u = _normalize_density(t_u, self._pdf(t_u, self.mu, self.sigma))
        return pred_u[inv]


@dataclass
class AxialDispersionRTD:
    name: str = "axdisp_2p"
    param_count: int = 2
    tau: float | None = None
    pe: float | None = None

    def _pdf_theta(self, theta: np.ndarray, pe: float) -> np.ndarray:
        theta = np.asarray(theta, dtype=float)
        e = np.zeros_like(theta)
        mask = theta > 0
        th = theta[mask]
        pref = 1.0 / (2.0 * np.sqrt(np.pi / pe))
        e_val = pref * (th ** (-1.5)) * np.exp(-(pe * (1.0 - th) ** 2) / (4.0 * th))
        e[mask] = e_val
        return np.nan_to_num(e, nan=0.0, posinf=0.0, neginf=0.0)

    def _pdf(self, t: np.ndarray, tau: float, pe: float) -> np.ndarray:
        theta = t / tau
        return self._pdf_theta(theta, pe) / tau

    def fit(self, t: np.ndarray, e: np.ndarray):
        t_u, e_u = _collapse_duplicates(t, e)
        tau0 = float(_safe_trapz(t_u * e_u, t_u))
        tau0 = max(tau0, 1e-6)
        pe0 = 10.0

        def obj(p: np.ndarray) -> float:
            tau, pe = p
            if tau <= 0 or pe <= 0:
                return 1e18
            pred = _normalize_density(t_u, self._pdf(t_u, tau, pe))
            return _mse(e_u, pred)

        res = optimize.minimize(obj, x0=np.array([tau0, pe0]), method="Nelder-Mead", options={"maxiter": 8000, "xatol": 1e-10, "fatol": 1e-12})
        tau_hat, pe_hat = res.x
        self.tau = float(max(tau_hat, 1e-9))
        self.pe = float(max(pe_hat, 1e-9))
        return self

    def predict(self, t: np.ndarray) -> np.ndarray:
        if self.tau is None or self.pe is None:
            raise RuntimeError("model not fitted")
        t_u, inv = _unique_grid(t)
        pred_u = _normalize_density(t_u, self._pdf(t_u, self.tau, self.pe))
        return pred_u[inv]
