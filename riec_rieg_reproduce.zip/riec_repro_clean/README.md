# RIEC-L1 reproducibility package (clean)

This is a cleaned, minimal, one-click reproducibility package for the RIEC-L1 experiments (Optics / RTD / Drying).

- One command regenerates: metrics tables (BIC / CV risk / XPE / C_lambda), selection JSONs, and all figures.
- Code files contain **no inline comments**; usage is documented here.

---

## 1. Quick start

### 1) Create a virtual environment (recommended)

```bash
python -m venv .venv
source .venv/bin/activate  # macOS/Linux
# .venv\\Scripts\\activate  # Windows PowerShell
```

### 2) Install requirements

```bash
pip install -r requirements.txt
```

### 3) Run everything

```bash
python run_all.py
```

Outputs are written to:

- `outputs/optics/`, `outputs/rtd/`, `outputs/drying/`

Each case produces:

- `tables/<case>/metrics.csv`
- `outputs/<case>/selected.json`
- `figures/<case>/*.png`

---

## 2. Data included

This package includes the data files found in the provided workspace:

- `data/optics/optics_demo.csv`
- `data/drying/drying_demo.csv`
- `data/rtd/data3.csv` and `data/rtd/data1.csv`

`data3.csv` is used for the RTD multi-run experiment.

If you want to reproduce *paper-specific* numbers with your full internal datasets, replace the demo files with your own data while keeping the same column names.

---

## 3. Input formats (if you replace data)

### Optics
CSV long-form with columns:

- `wavenumber`
- `reflectance`
- `condition_id` (used for leave-one-condition-out CV)

### RTD
`data3.csv` format:

- column `时间` (time)
- multiple run columns (e.g. `电导1`, `电导2`, `电导3`)

The code converts tracer response `c(t)` into an empirical kernel `E(t)` by baseline subtraction, non-negativity clamp, and integral normalization.

### Drying
CSV long-form with columns:

- `t`
- `MR`
- `condition_id` (used for LOCO)
- `T` (optional but recommended; required for Arrhenius-tied variants)

---

## 4. What is “expected_snapshot”?

`expected_snapshot/` contains pre-generated tables/figures from the original workspace as a quick inspection baseline.

It is not required to run the code, but it is useful for sanity-checking that your environment generates similar artifacts.

---

## 5. Chinese quick notes (中文说明)

- 一键运行：`python run_all.py`
- 产物目录：`tables/`（表），`figures/`（图），`outputs/`（选择结果 JSON）
- 数据目录：`data/`。如果你要换成“论文最终数据”，只要保持列名一致即可。

