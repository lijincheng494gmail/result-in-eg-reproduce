from pathlib import Path

import numpy as np

from riec.adapters.optics_adapter import load_optics_long
from riec.adapters.rtd_adapter import load_rtd_runs_long
from riec.adapters.drying_adapter import load_drying_long
from riec.cv import make_group_splits
from riec.core import ModelSpec, run_riec_selection
from riec.models.optics_models import CosinePolyModel
from riec.models.rtd_models import GammaRTD, LogNormalRTD, AxialDispersionRTD
from riec.models.drying_models import LewisDrying, PageDrying, WeibullDrying, TwoTermDrying, MidilliDrying, ArrheniusLewis, ArrheniusPage
from riec.reporting import save_metrics_table, save_selection_json, plot_bar_summary, plot_fit_overlay


def _lambda_weight(n_eff: int) -> float:
    return float(1.0 / np.log(max(int(n_eff), 3)))


def _first_existing(preferred: str, existing: list[str]) -> str:
    if preferred in existing:
        return preferred
    return existing[0]


def run_optics(root: Path) -> None:
    data_dir = root / "data" / "optics"
    csvs = sorted([p for p in data_dir.glob("*.csv") if p.is_file()])
    if not csvs:
        return
    df = load_optics_long(csvs)
    x = df["wavenumber"].to_numpy(dtype=float)
    y = df["reflectance"].to_numpy(dtype=float)
    splits = make_group_splits(df, "condition_id")
    specs = [
        ModelSpec(name=f"cos_poly_deg{d}", param_count=d + 4, factory=(lambda d=d: CosinePolyModel(deg=d)))
        for d in [0, 1, 2]
    ]
    baseline_name = "cos_poly_deg0"
    n_eff = len(df)
    lam = _lambda_weight(n_eff)
    scores_df, picks = run_riec_selection(x=x, y=y, models=specs, splits=splits, baseline_name=baseline_name, lambda_weight=lam, n_eff=n_eff)

    tables_dir = root / "tables" / "optics"
    figs_dir = root / "figures" / "optics"
    out_dir = root / "outputs" / "optics"

    save_metrics_table(scores_df, tables_dir / "metrics.csv")
    save_selection_json(picks, out_dir / "selected.json")

    plot_bar_summary(scores_df, "bic", figs_dir / "bic_bar.png", "Optics: BIC by model", ylabel="BIC (lower is better)")
    plot_bar_summary(scores_df, "cv_risk", figs_dir / "cv_risk_bar.png", "Optics: CV risk (MSE) by model", ylabel="CV risk (MSE)")
    plot_bar_summary(scores_df, "c_lambda", figs_dir / "c_lambda_bar.png", "Optics: C_lambda by model", ylabel="C_lambda (lower is better)")
    plot_bar_summary(scores_df, "xpe", figs_dir / "xpe_bar.png", "Optics: XPE by model", ylabel="XPE (baseline/CV risk)")

    holdout = _first_existing("angle10", list(df["condition_id"].unique()))
    df_te = df[df["condition_id"] == holdout]
    df_tr = df[df["condition_id"] != holdout]
    x_tr = df_tr["wavenumber"].to_numpy(dtype=float)
    y_tr = df_tr["reflectance"].to_numpy(dtype=float)
    x_te = df_te["wavenumber"].to_numpy(dtype=float)
    y_te = df_te["reflectance"].to_numpy(dtype=float)

    spec_map = {s.name: s for s in specs}
    preds = {}
    for key, model_name in picks.items():
        if model_name not in spec_map:
            continue
        m = spec_map[model_name].factory().fit(x_tr, y_tr)
        preds[f"{key}:{model_name}"] = m.predict(x_te)

    plot_fit_overlay(x_te, y_te, preds, figs_dir / f"fit_overlay_holdout_{holdout}.png", f"Optics: L0 hold-out prediction ({holdout})", xlabel="wavenumber", ylabel="reflectance")


def run_rtd(root: Path) -> None:
    data_path = root / "data" / "rtd" / "data3.csv"
    if not data_path.exists():
        return
    df = load_rtd_runs_long(data_path)
    x = df["t"].to_numpy(dtype=float)
    y = df["E"].to_numpy(dtype=float)
    splits = make_group_splits(df, "run_id")

    specs = [
        ModelSpec(name="gamma_2p", param_count=2, factory=lambda: GammaRTD()),
        ModelSpec(name="lognormal_2p", param_count=2, factory=lambda: LogNormalRTD()),
        ModelSpec(name="axdisp_2p", param_count=2, factory=lambda: AxialDispersionRTD()),
    ]

    baseline_name = "gamma_2p"
    n_eff = len(df)
    lam = _lambda_weight(n_eff)
    scores_df, picks = run_riec_selection(x=x, y=y, models=specs, splits=splits, baseline_name=baseline_name, lambda_weight=lam, n_eff=n_eff)

    tables_dir = root / "tables" / "rtd"
    figs_dir = root / "figures" / "rtd"
    out_dir = root / "outputs" / "rtd"

    save_metrics_table(scores_df, tables_dir / "metrics.csv")
    save_selection_json(picks, out_dir / "selected.json")

    plot_bar_summary(scores_df, "bic", figs_dir / "bic_bar.png", "RTD: BIC by model", ylabel="BIC (lower is better)")
    plot_bar_summary(scores_df, "cv_risk", figs_dir / "cv_risk_bar.png", "RTD: CV risk (MSE) by model", ylabel="CV risk (MSE)")
    plot_bar_summary(scores_df, "c_lambda", figs_dir / "c_lambda_bar.png", "RTD: C_lambda by model", ylabel="C_lambda (lower is better)")
    plot_bar_summary(scores_df, "xpe", figs_dir / "xpe_bar.png", "RTD: XPE by model", ylabel="XPE (baseline/CV risk)")

    holdout = _first_existing("run1", list(df["run_id"].unique()))
    df_te = df[df["run_id"] == holdout]
    df_tr = df[df["run_id"] != holdout]
    x_tr = df_tr["t"].to_numpy(dtype=float)
    y_tr = df_tr["E"].to_numpy(dtype=float)
    x_te = df_te["t"].to_numpy(dtype=float)
    y_te = df_te["E"].to_numpy(dtype=float)

    spec_map = {s.name: s for s in specs}
    preds = {}
    for key, model_name in picks.items():
        if model_name not in spec_map:
            continue
        m = spec_map[model_name].factory().fit(x_tr, y_tr)
        preds[f"{key}:{model_name}"] = m.predict(x_te)

    plot_fit_overlay(x_te, y_te, preds, figs_dir / f"fit_overlay_holdout_{holdout}.png", f"RTD: L0 hold-out prediction ({holdout})", xlabel="t", ylabel="E(t)")


def run_drying(root: Path) -> None:
    data_dir = root / "data" / "drying"
    csvs = sorted([p for p in data_dir.glob("*.csv") if p.is_file()])
    if not csvs:
        return
    path = csvs[0]
    df = load_drying_long(path)
    t = df["t"].to_numpy(dtype=float)
    y = df["MR"].to_numpy(dtype=float)
    if "T" in df.columns:
        T = df["T"].to_numpy(dtype=float)
        x = np.column_stack([t, T])
    else:
        x = t
    splits = make_group_splits(df, "condition_id")

    specs = [
        ModelSpec(name="lewis_1p", param_count=1, factory=lambda: LewisDrying()),
        ModelSpec(name="page_2p", param_count=2, factory=lambda: PageDrying()),
        ModelSpec(name="weibull_2p", param_count=2, factory=lambda: WeibullDrying()),
        ModelSpec(name="two_term_3p", param_count=3, factory=lambda: TwoTermDrying()),
        ModelSpec(name="midilli_4p", param_count=4, factory=lambda: MidilliDrying()),
        ModelSpec(name="arrhenius_lewis_2p", param_count=2, factory=lambda: ArrheniusLewis()),
        ModelSpec(name="arrhenius_page_3p", param_count=3, factory=lambda: ArrheniusPage()),
    ]

    baseline_name = "lewis_1p"
    n_eff = len(df)
    lam = _lambda_weight(n_eff)
    scores_df, picks = run_riec_selection(x=x, y=y, models=specs, splits=splits, baseline_name=baseline_name, lambda_weight=lam, n_eff=n_eff)

    tables_dir = root / "tables" / "drying"
    figs_dir = root / "figures" / "drying"
    out_dir = root / "outputs" / "drying"

    save_metrics_table(scores_df, tables_dir / "metrics.csv")
    save_selection_json(picks, out_dir / "selected.json")

    plot_bar_summary(scores_df, "bic", figs_dir / "bic_bar.png", "Drying: BIC by model", ylabel="BIC (lower is better)")
    plot_bar_summary(scores_df, "cv_risk", figs_dir / "cv_risk_bar.png", "Drying: CV risk (MSE) by model", ylabel="CV risk (MSE)")
    plot_bar_summary(scores_df, "c_lambda", figs_dir / "c_lambda_bar.png", "Drying: C_lambda by model", ylabel="C_lambda (lower is better)")
    plot_bar_summary(scores_df, "xpe", figs_dir / "xpe_bar.png", "Drying: XPE by model", ylabel="XPE (baseline/CV risk)")

    holdout = _first_existing("T50", list(df["condition_id"].unique()))
    df_te = df[df["condition_id"] == holdout]
    df_tr = df[df["condition_id"] != holdout]

    t_tr = df_tr["t"].to_numpy(dtype=float)
    y_tr = df_tr["MR"].to_numpy(dtype=float)
    t_te = df_te["t"].to_numpy(dtype=float)
    y_te = df_te["MR"].to_numpy(dtype=float)

    if "T" in df.columns:
        T_tr = df_tr["T"].to_numpy(dtype=float)
        T_te = df_te["T"].to_numpy(dtype=float)
        x_tr = np.column_stack([t_tr, T_tr])
        x_te = np.column_stack([t_te, T_te])
    else:
        x_tr = t_tr
        x_te = t_te

    spec_map = {s.name: s for s in specs}
    preds = {}
    for key, model_name in picks.items():
        if model_name not in spec_map:
            continue
        m = spec_map[model_name].factory().fit(x_tr, y_tr)
        preds[f"{key}:{model_name}"] = m.predict(x_te)

    plot_fit_overlay(t_te, y_te, preds, figs_dir / f"fit_overlay_holdout_{holdout}.png", f"Drying: L0 hold-out prediction ({holdout})", xlabel="t", ylabel="MR")


def main() -> int:
    root = Path(__file__).resolve().parent
    (root / "tables").mkdir(parents=True, exist_ok=True)
    (root / "figures").mkdir(parents=True, exist_ok=True)
    (root / "outputs").mkdir(parents=True, exist_ok=True)

    run_rtd(root)
    run_optics(root)
    run_drying(root)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
