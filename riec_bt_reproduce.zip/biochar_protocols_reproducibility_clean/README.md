# Reproducibility package: Biochar protocol sensitivity (BiocharDS)

This folder reproduces the core quantitative results of a protocol-sensitivity analysis using the open BiocharDS dataset:

- Curate a **cropping-only** analysis table (SOC lnRR outcome) with median imputation + missing indicators.
- Run a controlled protocol comparison (same linear model, protocol varies) across **P1–P5**:
  - P1: row-wise KFold
  - P2: study-grouped GroupKFold (leakage-safe)
  - P3: P2 + inverse-variance weighting (1/Var(lnRR))
  - P4: P3 + treatment-type stratification (B vs BF) implemented as indicator + rate interaction
  - P5: P4 + quadratic dose–response (rate^2)
- Generate the main tables and figures and a small audit report (leakage and weight concentration).

The code is intentionally kept free of inline comments; usage and outputs are documented here.

## Quick start

### 1) Create an environment and install dependencies

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
```

### 2) Run the full pipeline (one command)

From the repository root:

```bash
python src/run_all.py
```

Optional flags:

- Skip sensitivity runs:

```bash
python src/run_all.py --no_sensitivity
```

- Use a different seed / folds:

```bash
python src/run_all.py --seed 42 --folds 5
```

## Inputs

- `data/BiocharDS_V1.0.csv` (raw BiocharDS file; included)

## Outputs

All outputs are written under `outputs/`:

### Processed data

- `outputs/data/analysis_table_cropping.csv` (curated table used for all runs)
- `outputs/data/analysis_table_meta.json` (curation metadata + raw missing rates)

### Main tables

- `outputs/tables/Table1_descriptive_stats.csv`
- `outputs/tables/Table2_protocol_definitions.csv`
- `outputs/tables/Table3_protocol_summary.csv`

### Supplementary-style tables

- `outputs/tables/TableS1_protocol_drift.csv`
- `outputs/tables/TableS2_protocol_stability.csv`
- `outputs/tables/TableS4_leakage_by_fold.csv`
- `outputs/tables/TableS4_audit_metrics.csv`
- `outputs/tables/TableS0_sensitivity_runs.csv` (if sensitivity runs are enabled)
- `outputs/tables/fold_level_outputs.csv` (per-fold RMSE / OE / coefficients)

### Figures

- `outputs/figures/Fig1_entries_per_study.(png|pdf)`
- `outputs/figures/Fig2_rmse_by_protocol.(png|pdf)`
- `outputs/figures/Fig3_overall_effect_by_protocol.(png|pdf)`
- `outputs/figures/FigS1_drift_pairs.(png|pdf)`
- `outputs/figures/FigS2_rate_sign_flip.(png|pdf)`
- `outputs/figures/FigS_hist_*. (png|pdf)` (marginal distributions)

### Run manifest

- `outputs/run_manifest.json` (run settings + key audit numbers)

## Sanity-check expected values

With default settings (`--seed 42 --folds 5`), the key protocol summary (`outputs/tables/Table3_protocol_summary.csv`) should be close to:

- P1: rmse_mean ≈ 0.287, overall_mean ≈ 0.278
- P2: rmse_mean ≈ 0.318, overall_mean ≈ 0.275
- P3: rmse_mean ≈ 0.348, overall_mean ≈ 0.180
- P4: rmse_mean ≈ 0.351, overall_mean ≈ 0.189
- P5: rmse_mean ≈ 0.392, overall_mean ≈ 0.198

The audit table (`outputs/tables/TableS4_audit_metrics.csv`) should include:

- Row-wise leakage (rows) ≈ 0.98
- Inverse-variance weight concentration (top 5% share) ≈ 0.66

## Notes

- This package is self-contained (no downloads required for the included dataset file).
- It is suitable for anonymized review: it contains no author identifiers and no external repository links.
