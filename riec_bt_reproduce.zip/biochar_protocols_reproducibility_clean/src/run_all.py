import argparse
import warnings
warnings.filterwarnings("ignore", message="invalid value encountered in cast")
import json
import math
import pathlib
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold, GroupKFold
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

def read_csv_robust(path):
    encs = ["utf-8-sig", "utf-8", "cp1252", "latin1", "big5"]
    for enc in encs:
        try:
            return pd.read_csv(path, encoding=enc)
        except UnicodeDecodeError:
            continue
    return pd.read_csv(path)

def norm_col(c):
    return "".join(str(c).strip().split())

def to_num(s):
    return pd.to_numeric(s, errors="coerce")

def get_col(df, name):
    n = norm_col(name)
    if n in df.columns:
        return df[n]
    return pd.Series([np.nan] * len(df))

def compute_lnrr_var(df):
    mt = to_num(get_col(df, "SOC_T"))
    mc = to_num(get_col(df, "SOC_CK"))
    sdt = to_num(get_col(df, "SOC_T_SD"))
    sdc = to_num(get_col(df, "SOC_CK_SD"))
    nt = to_num(get_col(df, "SOC_T_N"))
    nc = to_num(get_col(df, "SOC_CK_N"))
    v = (sdt ** 2) / (nt * (mt ** 2)) + (sdc ** 2) / (nc * (mc ** 2))
    v = v.where(np.isfinite(v) & (v > 0), np.nan)
    return v

def build_analysis_table(raw_path, out_dir):
    out_dir = pathlib.Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df_raw = read_csv_robust(raw_path)
    df_raw = df_raw.copy()
    df_raw.columns = [norm_col(c) for c in df_raw.columns]

    sid = to_num(get_col(df_raw, "StudyID"))

    tbl = pd.DataFrame({
        "study_id": sid,
        "y": to_num(get_col(df_raw, "SOC_LNRR")),
        "rate": to_num(get_col(df_raw, "BiocharAddition")),
        "pyrolysis_temp": to_num(get_col(df_raw, "PyrolysisTemperature_biochar")),
        "soil_pH0": to_num(get_col(df_raw, "pH_initial")),
        "MAT": to_num(get_col(df_raw, "Temperature")),
        "MAP": to_num(get_col(df_raw, "Precipitation")),
        "treat_raw": get_col(df_raw, "Treatment").astype(str),
        "crop_type": get_col(df_raw, "CropType"),
    })

    tbl["treat_type"] = np.where(tbl["treat_raw"].str.upper().eq("B"), "B", "BF")
    tbl["exp_type"] = np.where(tbl["crop_type"].notna() & (tbl["crop_type"].astype(str).str.len() > 0), "cropping", "incubation")
    tbl["v"] = compute_lnrr_var(df_raw)

    tbl = tbl[tbl["y"].notna()].copy()
    tbl = tbl[tbl["exp_type"].eq("cropping")].copy()
    tbl = tbl.dropna(subset=["study_id", "rate", "y"]).copy()

    tbl["study_id"] = to_num(tbl["study_id"]).astype(int)

    covs = ["rate", "pyrolysis_temp", "soil_pH0", "MAT", "MAP"]
    raw_missing = {}
    for c in covs:
        miss = tbl[c].isna()
        raw_missing[c] = float(miss.mean())
        tbl[f"{c}_missing"] = miss.astype(int)
        med = float(tbl[c].median(skipna=True)) if np.isfinite(tbl[c].median(skipna=True)) else 0.0
        tbl.loc[miss, c] = med

    analysis_path = out_dir / "analysis_table_cropping.csv"
    tbl.to_csv(analysis_path, index=False)

    meta = {
        "raw_path": str(raw_path),
        "n_rows": int(len(tbl)),
        "n_studies": int(tbl["study_id"].nunique()),
        "raw_missing_rates": raw_missing,
        "covariates": covs,
        "seed_default": 42
    }
    (out_dir / "analysis_table_meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")

    return tbl, meta

def clamp_weights(w):
    w = np.asarray(w, dtype=float)
    w = np.clip(w, 1e-6, 1e6)
    w[~np.isfinite(w)] = 1.0
    return w

def protocol_definitions():
    rows = [
        {"protocol": "P1", "split": "row", "weighting": "none", "treatment_strat": False, "dose_response": "linear", "description": "Naive row-wise KFold; linear main effects"},
        {"protocol": "P2", "split": "group", "weighting": "none", "treatment_strat": False, "dose_response": "linear", "description": "GroupKFold by study_id; linear main effects (leakage-safe)"},
        {"protocol": "P3", "split": "group", "weighting": "inv_var", "treatment_strat": False, "dose_response": "linear", "description": "P2 + inverse-variance weighting (classic meta weighting)"},
        {"protocol": "P4", "split": "group", "weighting": "inv_var", "treatment_strat": True, "dose_response": "linear", "description": "P3 + treatment type (B vs BF) via indicator + rate interaction"},
        {"protocol": "P5", "split": "group", "weighting": "inv_var", "treatment_strat": True, "dose_response": "quadratic", "description": "P4 + quadratic dose-response (rate^2)"},
    ]
    return pd.DataFrame(rows)

def design_matrix(df, proto):
    covs = ["rate", "pyrolysis_temp", "soil_pH0", "MAT", "MAP",
            "rate_missing", "pyrolysis_temp_missing", "soil_pH0_missing", "MAT_missing", "MAP_missing"]
    X = df[covs].copy()
    if proto == "P5":
        X["rate_sq"] = df["rate"].values ** 2
    if proto in ["P4", "P5"]:
        is_bf = (df["treat_type"] == "BF").astype(int)
        X["is_BF"] = is_bf
        X["is_BF_x_rate"] = is_bf * df["rate"].values
    return X

def get_splitter(proto, folds, seed):
    if proto == "P1":
        return KFold(n_splits=folds, shuffle=True, random_state=seed)
    return GroupKFold(n_splits=folds)

def get_weights_vec(df, proto):
    if proto in ["P3", "P4", "P5"]:
        v = df["v"].values
        with np.errstate(divide="ignore", invalid="ignore"):
            w = 1.0 / v
        return clamp_weights(w)
    return np.ones(len(df), dtype=float)

def fold_sign_flip_rate(values):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    if len(v) <= 1:
        return 0.0
    s = np.sign(v)
    return float(np.mean(s[1:] != s[:-1]))

def run_protocol(df, proto, folds, seed):
    Xdf = design_matrix(df, proto)
    X = Xdf.values
    y = df["y"].values
    w = get_weights_vec(df, proto)
    groups = df["study_id"].values

    ref = Xdf.mean(numeric_only=True).copy()
    for c in ref.index:
        if c == "is_BF" or c.startswith("is_BF_x_"):
            ref[c] = 0.0
    ref_vec = ref.values.reshape(1, -1)

    splitter = get_splitter(proto, folds, seed)
    if proto == "P1":
        split_iter = splitter.split(X, y)
    else:
        split_iter = splitter.split(X, y, groups=groups)

    cols = list(Xdf.columns)
    rate_idx = cols.index("rate")

    rows_fold = []
    rate_coefs = []
    for k, (tr, te) in enumerate(split_iter, start=1):
        model = LinearRegression()
        model.fit(X[tr], y[tr], sample_weight=w[tr])
        yhat = model.predict(X[te])
        rmse = float(np.sqrt(np.mean((yhat - y[te]) ** 2)))
        oe = float(model.predict(ref_vec)[0])
        rate_b = float(model.coef_[rate_idx])
        rows_fold.append({"protocol": proto, "fold": int(k), "rmse": rmse, "overall_effect": oe, "rate_coef": rate_b, "n_test": int(len(te))})
        rate_coefs.append(rate_b)

    rmses = [r["rmse"] for r in rows_fold]
    oes = [r["overall_effect"] for r in rows_fold]
    out = {
        "protocol": proto,
        "rmse_mean": float(np.mean(rmses)),
        "rmse_sd": float(np.std(rmses, ddof=1)),
        "overall_mean": float(np.mean(oes)),
        "overall_sd": float(np.std(oes, ddof=1)),
        "rate_sign_flip": fold_sign_flip_rate(rate_coefs),
        "fold_table": pd.DataFrame(rows_fold)
    }
    return out

def protocol_suite(df, folds, seed):
    protos = ["P1", "P2", "P3", "P4", "P5"]
    results = {}
    for p in protos:
        results[p] = run_protocol(df, p, folds, seed)
    summary = pd.DataFrame([{
        "protocol": p,
        "rmse_mean": results[p]["rmse_mean"],
        "rmse_sd": results[p]["rmse_sd"],
        "overall_mean": results[p]["overall_mean"],
        "overall_sd": results[p]["overall_sd"],
        "rate_sign_flip": results[p]["rate_sign_flip"],
        "pct": 100.0 * (math.exp(results[p]["overall_mean"]) - 1.0)
    } for p in protos])

    drift_rows = []
    for i in range(len(protos)):
        for j in range(i + 1, len(protos)):
            pi, pj = protos[i], protos[j]
            drift_rows.append({"pair": f"{pi}-{pj}", "diff_overall": results[pi]["overall_mean"] - results[pj]["overall_mean"]})
    drift = pd.DataFrame(drift_rows)

    stability = summary[["protocol", "overall_sd", "rmse_sd", "rate_sign_flip"]].copy()

    folds_all = pd.concat([results[p]["fold_table"] for p in protos], ignore_index=True)

    return summary, drift, stability, folds_all, results

def leakage_audit(df, folds, seed):
    groups = df["study_id"].values
    idx = np.arange(len(df))
    splitter = KFold(n_splits=folds, shuffle=True, random_state=seed)
    rows = []
    for k, (tr, te) in enumerate(splitter.split(idx), start=1):
        tr_st = set(groups[tr])
        te_st = set(groups[te])
        leak_rows = float(np.mean([g in tr_st for g in groups[te]]))
        leak_studies = float(len(te_st & tr_st) / len(te_st)) if len(te_st) else 0.0
        rows.append({"fold": int(k), "leak_rows": leak_rows, "leak_studies": leak_studies, "n_test": int(len(te))})
    tab = pd.DataFrame(rows)
    return {
        "leak_rows_mean": float(tab["leak_rows"].mean()),
        "leak_rows_sd": float(tab["leak_rows"].std(ddof=1)),
        "leak_studies_mean": float(tab["leak_studies"].mean()),
        "leak_studies_sd": float(tab["leak_studies"].std(ddof=1)),
        "by_fold": tab
    }

def weight_concentration(df):
    v = df["v"].values
    with np.errstate(divide="ignore", invalid="ignore"):
        w = 1.0 / v
    w = clamp_weights(w)
    n = len(w)
    k = int(math.ceil(0.05 * n))
    top = float(np.sort(w)[::-1][:k].sum() / w.sum()) if w.sum() > 0 else 0.0
    miss_v = float(np.mean(~np.isfinite(v))) if n else 0.0
    return {"top5_share": top, "n": int(n), "k": int(k), "v_missing_rate": miss_v}

def fig_save(path, fig):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, bbox_inches="tight", dpi=250)
    plt.close(fig)

def make_figures(df, out_fig_dir, summary, drift):
    out_fig_dir = pathlib.Path(out_fig_dir)
    out_fig_dir.mkdir(parents=True, exist_ok=True)

    if "study_id" in df.columns:
        eps = df.groupby("study_id").size().sort_values(ascending=False)
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(np.arange(len(eps)), eps.values)
        ax.set_xlabel("Study (sorted)")
        ax.set_ylabel("Entries per study")
        ax.set_title("Entries per study (evidence of clustering)")
        fig_save(out_fig_dir / "Fig1_entries_per_study.png", fig)
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.bar(np.arange(len(eps)), eps.values)
        ax.set_xlabel("Study (sorted)")
        ax.set_ylabel("Entries per study")
        ax.set_title("Entries per study (evidence of clustering)")
        fig_save(out_fig_dir / "Fig1_entries_per_study.pdf", fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["rmse_mean"], yerr=summary["rmse_sd"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Test RMSE (lnRR)")
    ax.set_title("Out-of-sample RMSE by protocol")
    fig_save(out_fig_dir / "Fig2_rmse_by_protocol.png", fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["rmse_mean"], yerr=summary["rmse_sd"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Test RMSE (lnRR)")
    ax.set_title("Out-of-sample RMSE by protocol")
    fig_save(out_fig_dir / "Fig2_rmse_by_protocol.pdf", fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["overall_mean"], yerr=summary["overall_sd"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Overall effect (SOC lnRR)")
    ax.set_title("Overall SOC response by protocol (mean ± SD across folds)")
    fig_save(out_fig_dir / "Fig3_overall_effect_by_protocol.png", fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["overall_mean"], yerr=summary["overall_sd"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Overall effect (SOC lnRR)")
    ax.set_title("Overall SOC response by protocol (mean ± SD across folds)")
    fig_save(out_fig_dir / "Fig3_overall_effect_by_protocol.pdf", fig)

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(drift["pair"], drift["diff_overall"])
    ax.set_xlabel("Protocol pair")
    ax.set_ylabel("Difference in overall effect (lnRR)")
    ax.set_title("Between-protocol drift in overall effect")
    fig_save(out_fig_dir / "FigS1_drift_pairs.png", fig)
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(drift["pair"], drift["diff_overall"])
    ax.set_xlabel("Protocol pair")
    ax.set_ylabel("Difference in overall effect (lnRR)")
    ax.set_title("Between-protocol drift in overall effect")
    fig_save(out_fig_dir / "FigS1_drift_pairs.pdf", fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["rate_sign_flip"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Sign flip rate (rate coefficient)")
    ax.set_title("Coefficient sign instability across folds")
    fig_save(out_fig_dir / "FigS2_rate_sign_flip.png", fig)
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.bar(summary["protocol"], summary["rate_sign_flip"])
    ax.set_xlabel("Protocol")
    ax.set_ylabel("Sign flip rate (rate coefficient)")
    ax.set_title("Coefficient sign instability across folds")
    fig_save(out_fig_dir / "FigS2_rate_sign_flip.pdf", fig)

    for v in ["MAP", "MAT", "pyrolysis_temp", "rate", "soil_pH0", "y"]:
        if v not in df.columns:
            continue
        fig, ax = plt.subplots(figsize=(5, 3.5))
        ax.hist(df[v].values, bins=30)
        ax.set_xlabel(v)
        ax.set_ylabel("Count")
        ax.set_title(f"Distribution of {v}")
        fig_save(out_fig_dir / f"FigS_hist_{v}.png", fig)
        fig, ax = plt.subplots(figsize=(5, 3.5))
        ax.hist(df[v].values, bins=30)
        ax.set_xlabel(v)
        ax.set_ylabel("Count")
        ax.set_title(f"Distribution of {v}")
        fig_save(out_fig_dir / f"FigS_hist_{v}.pdf", fig)

def table1_describe(df, meta):
    vars_ = ["rate", "pyrolysis_temp", "soil_pH0", "MAT", "MAP", "y"]
    desc = df[vars_].describe(percentiles=[0.25, 0.5, 0.75]).T.reset_index().rename(columns={"index": "variable"})
    miss_raw = []
    for v in vars_:
        if v in meta["raw_missing_rates"]:
            mr = meta["raw_missing_rates"][v]
        else:
            mr = 0.0
        miss_raw.append({"variable": v, "missing_rate_raw": mr})
    miss_raw = pd.DataFrame(miss_raw)
    out = desc.merge(miss_raw, on="variable", how="left")
    out["missing_rate_post_imputation"] = 0.0
    return out

def sensitivity_runs(df, folds, seed):
    rows = []
    for tag, dsub in [
        ("paper_main", df),
        ("paper_Bonly", df[df["treat_type"] == "B"].copy()),
        ("paper_BFonly", df[df["treat_type"] == "BF"].copy()),
    ]:
        summary, _, _, _, _ = protocol_suite(dsub, folds, seed)
        summary2 = summary.copy()
        summary2.insert(0, "run", tag)
        rows.append(summary2)

    summary10, _, _, _, _ = protocol_suite(df, 10, seed)
    summary10 = summary10.copy()
    summary10.insert(0, "run", "paper_10fold")
    rows.append(summary10)

    cc = df.copy()
    for c in ["pyrolysis_temp", "soil_pH0", "MAT", "MAP"]:
        cc = cc[cc[f"{c}_missing"] == 0].copy()
    summary_cc, _, _, _, _ = protocol_suite(cc, folds, seed)
    summary_cc = summary_cc.copy()
    summary_cc.insert(0, "run", "paper_complete_case")
    rows.append(summary_cc)

    out = pd.concat(rows, ignore_index=True)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", type=str, default=str(pathlib.Path("data") / "BiocharDS_V1.0.csv"))
    ap.add_argument("--out", type=str, default="outputs")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--folds", type=int, default=5)
    ap.add_argument("--no_sensitivity", action="store_true")
    args = ap.parse_args()

    out_root = pathlib.Path(args.out)
    out_data = out_root / "data"
    out_tables = out_root / "tables"
    out_figs = out_root / "figures"
    out_data.mkdir(parents=True, exist_ok=True)
    out_tables.mkdir(parents=True, exist_ok=True)
    out_figs.mkdir(parents=True, exist_ok=True)

    df, meta = build_analysis_table(args.raw, out_data)

    t1 = table1_describe(df, meta)
    t1.to_csv(out_tables / "Table1_descriptive_stats.csv", index=False)

    t2 = protocol_definitions()
    t2.to_csv(out_tables / "Table2_protocol_definitions.csv", index=False)

    summary, drift, stability, folds_all, _ = protocol_suite(df, args.folds, args.seed)
    summary.to_csv(out_tables / "Table3_protocol_summary.csv", index=False)
    drift.to_csv(out_tables / "TableS1_protocol_drift.csv", index=False)
    stability.to_csv(out_tables / "TableS2_protocol_stability.csv", index=False)
    folds_all.to_csv(out_tables / "fold_level_outputs.csv", index=False)

    leak = leakage_audit(df, args.folds, args.seed)
    leak["by_fold"].to_csv(out_tables / "TableS4_leakage_by_fold.csv", index=False)

    wconc = weight_concentration(df)
    audit = pd.DataFrame([{
        "row_split_leak_rows_mean": leak["leak_rows_mean"],
        "row_split_leak_studies_mean": leak["leak_studies_mean"],
        "inv_var_top5_weight_share": wconc["top5_share"],
        "v_missing_rate": wconc["v_missing_rate"],
        "n_entries": meta["n_rows"],
        "n_studies": meta["n_studies"]
    }])
    audit.to_csv(out_tables / "TableS4_audit_metrics.csv", index=False)

    make_figures(df, out_figs, summary, drift)

    if not args.no_sensitivity:
        sens = sensitivity_runs(df, args.folds, args.seed)
        sens.to_csv(out_tables / "TableS0_sensitivity_runs.csv", index=False)

    runinfo = {
        "raw": args.raw,
        "out": str(out_root),
        "seed": int(args.seed),
        "folds": int(args.folds),
        "n_entries": meta["n_rows"],
        "n_studies": meta["n_studies"],
        "audit": {
            "row_split_leak_rows_mean": leak["leak_rows_mean"],
            "row_split_leak_studies_mean": leak["leak_studies_mean"],
            "inv_var_top5_weight_share": wconc["top5_share"]
        }
    }
    (out_root / "run_manifest.json").write_text(json.dumps(runinfo, indent=2), encoding="utf-8")

    print("Done.")
    print(f"Outputs: {out_root}")

if __name__ == "__main__":
    main()
